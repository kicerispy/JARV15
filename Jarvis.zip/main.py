from ollama import chat
import json
import time

import memory
import conversation
import memory_ai
import tools
import planner
import voice
import speech
import wakeword


MODEL = "gemma4:e2b"

# ============================================================
# CONTINUOUS CONVERSATION
# ============================================================

CONTINUOUS_MODE_DEFAULT = True


# ============================================================
# USER PROFILE
# ============================================================

with open(
    "profile.json",
    "r",
    encoding="utf-8"
) as file:

    profile = json.load(file)

user_name = profile["name"]


# ============================================================
# ACTIVE TASK CONTEXT
# ============================================================

active_context = {
    "site": None,
    "last_query": None,
    "last_tool": None,
    "last_result": None,
}


# ============================================================
# TASK STATE
# ============================================================

task_state = {
    "active": False,
    "cancelled": False,
    "description": None,
    "total_steps": 0,
    "current_step": 0,
    "current_tool": None,
}


def start_task(description, total_steps):

    global task_state

    task_state = {
        "active": True,
        "cancelled": False,
        "description": description,
        "total_steps": total_steps,
        "current_step": 0,
        "current_tool": None,
    }


def update_task_step(
    step_number,
    tool_name
):

    global task_state

    task_state["current_step"] = (
        step_number
    )

    task_state["current_tool"] = (
        tool_name
    )


def cancel_task():

    global task_state

    task_state["cancelled"] = True


def finish_task():

    global task_state

    task_state = {
        "active": False,
        "cancelled": False,
        "description": None,
        "total_steps": 0,
        "current_step": 0,
        "current_tool": None,
    }


def task_is_cancelled():

    return bool(
        task_state.get(
            "cancelled",
            False
        )
    )


# ============================================================
# PENDING INPUT
# ============================================================

pending_input = None


# ============================================================
# CONVERSATION MODE
# ============================================================

continuous_mode = False


# ============================================================
# MEMORY CONTEXT
# ============================================================

def get_memory_context():

    memories = memory.get_memories()

    if not memories:
        return "No saved memories."

    memory_text = ""

    for item in memories:

        memory_text += (
            f"- {item[0]}\n"
        )

    return memory_text


# ============================================================
# JARVIS PERSONALITY
# ============================================================

system_prompt = f"""
You are JARVIS, a personal AI assistant.

You are calm, precise, intelligent, and efficient.

Keep answers concise unless the user asks for more detail.

Address the user naturally as {user_name} when appropriate.

Use saved memories and recent conversation context when relevant.

Do not pretend to have completed an action unless a tool
actually completed it.

When a tool has completed an action, treat that result as
part of the conversation context.
"""


# ============================================================
# RECENT CONVERSATION
# ============================================================

def get_recent_history(limit=10):

    try:

        history = conversation.get_history()

        if not history:
            return []

        return history[-limit:]

    except Exception as e:

        print(
            "Conversation history error:",
            e
        )

        return []


# ============================================================
# NORMALIZE COMMAND
# ============================================================

def normalize_command(text):

    if not text:
        return ""

    text = str(text)

    text = text.strip()

    text = text.rstrip(
        ".,!?"
    )

    text = " ".join(
        text.split()
    )

    return text.strip()


# ============================================================
# CANCEL COMMANDS
# ============================================================

def is_cancel_command(text):

    normalized = normalize_command(
        text
    ).lower()

    if not normalized:
        return False

    return normalized in {
        "stop",
        "stop talking",
        "stop speaking",
        "cancel",
        "cancel that",
        "cancel it",
        "never mind",
        "nevermind",
        "that's enough",
        "thats enough",
        "enough",
    }


# ============================================================
# END CONTINUOUS CONVERSATION
# ============================================================

def is_end_conversation_command(text):

    normalized = normalize_command(
        text
    ).lower()

    if not normalized:
        return False

    return normalized in {
        "go to sleep",
        "go back to sleep",
        "sleep",
        "to sleep",
        "back to sleep",
        "go sleep",
        "end conversation",
        "end the conversation",
        "conversation off",
        "stop listening",
        "stop listening to me",
        "that's all",
        "thats all",
        "we're done",
        "were done",
        "we are done",
        "goodbye jarvis",
    }


# ============================================================
# COMMANDS THAT SHOULD NEVER GO THROUGH THE
# CONTEXT RESOLVER
# ============================================================

def should_resolve_context(text):

    normalized = normalize_command(
        text
    ).lower()

    if not normalized:
        return False

    direct_prefixes = (
        "open ",
        "launch ",
        "start ",
        "search ",
        "searching ",
        "find ",
        "click ",
        "double click ",
        "double-click ",
        "type ",
        "move ",
        "scroll ",
        "press ",
        "take ",
        "capture ",
        "what ",
        "what's ",
        "whats ",
        "what is ",
        "current ",
        "get ",
    )

    if normalized.startswith(
        direct_prefixes
    ):
        return False

    contextual_phrases = (
        "now ",
        "then ",
        "also ",
        "actually ",
        "instead ",
        "make it ",
        "use ",
        "change it",
        "do that",
        "do it",
        "try that",
        "try it",
        "look for ",
        "find it",
        "look it up",
        "open that",
        "close that",
        "click that",
        "click it",
        "what about ",
        "what about it",
        "go there",
    )

    if normalized.startswith(
        contextual_phrases
    ):
        return True

    reference_words = {
        "it",
        "that",
        "this",
        "those",
        "these",
        "there",
        "again",
        "another",
        "previous",
        "same",
        "one",
    }

    words = normalized.split()

    if any(
        word in reference_words
        for word in words
    ):
        return True

    return False


# ============================================================
# RESOLVE FOLLOW-UP
# ============================================================

def resolve_followup(user_input):

    if not should_resolve_context(
        user_input
    ):
        return user_input

    history = get_recent_history(
        limit=10
    )

    history_text = ""

    for message in history:

        role = message.get(
            "role",
            ""
        )

        content = message.get(
            "content",
            ""
        )

        if content:

            history_text += (
                f"{role.upper()}: "
                f"{content}\n"
            )

    active_site = active_context.get(
        "site"
    )

    last_query = active_context.get(
        "last_query"
    )

    last_tool = active_context.get(
        "last_tool"
    )

    last_result = active_context.get(
        "last_result"
    )

    prompt = f"""
You are JARVIS's command-context resolver.

Rewrite the user's latest command into ONE standalone
instruction for JARVIS's task planner.

Do NOT answer the user.
Do NOT explain your reasoning.
Return ONLY the standalone instruction.

Rules:

1. Preserve the active task context when appropriate.

2. If the active website is YouTube and the user says:
   "look for the trailer"
   rewrite it as:
   "Search YouTube for the Iron Man trailer."

3. If the user says:
   "look for another one"
   preserve the active website and subject when possible.

4. Never replace a known website with generic web search.

5. Resolve references like:
   "it"
   "that"
   "this"
   "the trailer"
   "the video"
   "the previous one"
   "another one"
   "there"

6. Do not invent information.

7. Preserve explicit information from the latest command.

ACTIVE TASK:

Website:
{active_site or "none"}

Previous search:
{last_query or "none"}

Previous tool:
{last_tool or "none"}

Previous result:
{last_result or "none"}

RECENT CONVERSATION:

{history_text}

LATEST COMMAND:

{user_input}
"""

    try:

        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": prompt
                }
            ],
            options={
                "temperature": 0.0
            }
        )

        resolved = (
            response["message"]["content"]
            .strip()
        )

        if not resolved:
            return user_input

        if len(resolved) > 500:
            return user_input

        print(
            "JARVIS context:"
        )

        print(
            f"  Original: {user_input}"
        )

        print(
            f"  Resolved: {resolved}"
        )

        return resolved

    except Exception as e:

        print(
            "Context resolution skipped:",
            e
        )

        return user_input


# ============================================================
# UPDATE ACTIVE TASK CONTEXT
# ============================================================

def update_active_context(
    plan,
    result_message=""
):

    steps = plan.get(
        "steps",
        []
    )

    if not isinstance(
        steps,
        list
    ):
        return

    for step in steps:

        tool_name = step.get(
            "tool",
            ""
        )

        argument = step.get(
            "argument",
            ""
        )

        if tool_name == "search_website":

            parts = argument.split(
                "|",
                1
            )

            if len(parts) == 2:

                active_context["site"] = (
                    parts[0]
                    .strip()
                    .lower()
                )

                active_context["last_query"] = (
                    parts[1]
                    .strip()
                )

            active_context["last_tool"] = (
                tool_name
            )

            if result_message:

                active_context["last_result"] = (
                    str(result_message)
                )

        elif tool_name in {
            "open_website",
            "open_program",
            "click_screen",
            "double_click_screen",
            "move_mouse",
            "scroll_screen",
            "type_text",
            "press_key",
            "analyze_screen",
            "capture_screen",
            "weather",
            "current_time",
            "current_date",
            "system_status",
            "jarvis_status",
        }:

            active_context["last_tool"] = (
                tool_name
            )

            if result_message:

                active_context["last_result"] = (
                    str(result_message)
                )


# ============================================================
# CLEAR ACTIVE CONTEXT
# ============================================================

def clear_active_context():

    global active_context

    active_context = {
        "site": None,
        "last_query": None,
        "last_tool": None,
        "last_result": None,
    }


# ============================================================
# SAFE TTS
# ============================================================

def speak(text):

    if not text:
        return False

    try:

        voice.speak(
            str(text)
        )

        return voice.was_interrupted()

    except Exception as e:

        print(
            "Voice error:",
            e
        )

        return False


# ============================================================
# LISTEN AFTER BARGE-IN
# ============================================================

def listen_after_barge_in():

    if not voice.was_interrupted():

        return None

    print(
        "\nJARVIS: Barge-in detected."
    )

    interrupted_audio = (
        voice.get_interrupted_audio()
    )

    time.sleep(
        0.15
    )

    try:

        result = speech.listen(
            initial_audio=interrupted_audio,
            mode="continuous"
        )

        if result:

            print(
                f"JARVIS: Barge-in command captured: {result}"
            )

            return result

        print(
            "JARVIS: Barge-in speech was not transcribed."
        )

        return None

    except Exception as e:

        print(
            "JARVIS: Barge-in listening error:",
            e
        )

        return None

    finally:

        voice.clear_interruption()


# ============================================================
# NORMAL GEMMA CONVERSATION
# ============================================================

def handle_normal_conversation():

    global pending_input

    messages = (
        build_conversation_messages()
    )

    try:

        response = chat(
            model=MODEL,
            messages=messages
        )

        jarvis_reply = (
            response["message"]["content"]
            .strip()
        )

    except Exception as e:

        print(
            "Ollama error:",
            e
        )

        jarvis_reply = (
            "I encountered an error "
            "while processing that."
        )

    conversation.add_message(
        "assistant",
        jarvis_reply
    )

    print(
        "JARVIS:",
        jarvis_reply
    )

    interrupted = speak(
        jarvis_reply
    )

    if interrupted:

        pending_input = (
            listen_after_barge_in()
        )

        if pending_input:

            return "interrupted"

    return "done"


# ============================================================
# BUILD GEMMA MESSAGES
# ============================================================

def build_conversation_messages():

    current_memories = (
        get_memory_context()
    )

    active_site = active_context.get(
        "site"
    )

    active_query = active_context.get(
        "last_query"
    )

    active_tool = active_context.get(
        "last_tool"
    )

    active_task_text = f"""
Current active task context:

Website:
{active_site or "none"}

Search query:
{active_query or "none"}

Last tool:
{active_tool or "none"}
"""

    messages = [
        {
            "role": "system",
            "content":
                system_prompt +
                f"""

Relevant memories:

{current_memories}

{active_task_text}

Use these naturally when relevant.
"""
        }
    ]

    messages.extend(
        get_recent_history(
            limit=12
        )
    )

    return messages


# ============================================================
# PROCESS ONE COMMAND
# ============================================================

def process_command(user_input):

    global pending_input
    global continuous_mode

    if user_input is None:

        return "done"

    user_input = normalize_command(
        user_input
    )

    if not user_input:

        return "done"

    print(
        f"\nUSER: {user_input}"
    )


    # ========================================================
    # END CONVERSATION
    # ========================================================

    if is_end_conversation_command(
        user_input
    ):

        print(
            "JARVIS: Returning to wake-word mode."
        )

        continuous_mode = False

        clear_active_context()

        finish_task()

        pending_input = None

        try:

            voice.clear_interruption()

        except Exception:

            pass

        return "done"


    # ========================================================
    # CANCEL
    # ========================================================

    if is_cancel_command(
        user_input
    ):

        # Mark the current task cancelled first.
        cancel_task()

        # Immediately leave continuous mode.
        continuous_mode = False

        # Remove any queued input.
        pending_input = None

        # Clear task-related context.
        clear_active_context()

        try:

            voice.clear_interruption()

        except Exception:

            pass

        if task_state.get(
            "active",
            False
        ):

            print(
                "JARVIS: Active task cancelled."
            )

        else:

            print(
                "JARVIS: Command cancelled."
            )

        # Reset the task after cancellation
        # has been recorded.
        finish_task()

        return "cancelled"


    # ========================================================
    # SHUTDOWN
    # ========================================================

    if user_input.lower() in {
        "quit",
        "exit",
        "shutdown",
        "shut down",
    }:

        finish_task()

        reply = (
            "Shutting down. Goodbye."
        )

        conversation.add_message(
            "user",
            user_input
        )

        conversation.add_message(
            "assistant",
            reply
        )

        print(
            "JARVIS:",
            reply
        )

        speak(
            reply
        )

        return "shutdown"


    # ========================================================
    # REMEMBER
    # ========================================================

    if user_input.lower().startswith(
        "remember"
    ):

        fact = (
            user_input[8:]
            .strip()
        )

        conversation.add_message(
            "user",
            user_input
        )

        if fact:

            memory.save_memory(
                fact
            )

            reply = (
                "I will remember that."
            )

        else:

            reply = (
                "What would you like "
                "me to remember?"
            )

        conversation.add_message(
            "assistant",
            reply
        )

        print(
            "JARVIS:",
            reply
        )

        interrupted = speak(
            reply
        )

        if interrupted:

            pending_input = (
                listen_after_barge_in()
            )

            if pending_input:

                return "interrupted"

        return "done"


    # ========================================================
    # SHOW MEMORIES
    # ========================================================

    if user_input.lower() == (
        "what do you remember"
    ):

        memories = (
            memory.get_memories()
        )

        if not memories:

            reply = (
                "I currently have "
                "no saved memories."
            )

        else:

            print(
                "JARVIS memories:"
            )

            memory_items = []

            for item in memories:

                print(
                    "-",
                    item[0]
                )

                memory_items.append(
                    item[0]
                )

            reply = (
                "Your saved memories are: "
                + ". ".join(
                    memory_items
                )
            )

        conversation.add_message(
            "user",
            user_input
        )

        conversation.add_message(
            "assistant",
            reply
        )

        print(
            "JARVIS:",
            reply
        )

        interrupted = speak(
            reply
        )

        if interrupted:

            pending_input = (
                listen_after_barge_in()
            )

            if pending_input:

                return "interrupted"

        return "done"


    # ========================================================
    # MEMORY ANALYSIS
    # ========================================================

    try:

        memory_ai.analyze_memory(
            user_input
        )

    except Exception as e:

        print(
            "Memory analysis skipped:",
            e
        )


    # ========================================================
    # SAVE USER INPUT
    # ========================================================

    conversation.add_message(
        "user",
        user_input
    )


    # ========================================================
    # CONTEXT RESOLUTION
    # ========================================================

    planning_input = resolve_followup(
        user_input
    )


    # ========================================================
    # CREATE PLAN
    # ========================================================

    try:

        plan = planner.create_plan(
            planning_input
        )

    except Exception as e:

        print(
            "Planner error:",
            e
        )

        plan = {
            "steps": []
        }


    steps = plan.get(
        "steps",
        []
    )


    # ========================================================
    # NORMAL CONVERSATION
    # ========================================================

    if not steps:

        return handle_normal_conversation()


    # ========================================================
    # TOOL EXECUTION
    # ========================================================

    task_failed = False
    task_completed = False

    final_tool_message = ""


    executable_steps = [
        step
        for step in steps
        if step.get(
            "tool",
            ""
        )
        not in {
            "",
            "none"
        }
    ]


    multi_step = (
        len(executable_steps) > 1
    )


    # ========================================================
    # START TASK
    # ========================================================

    start_task(
        description=planning_input,
        total_steps=len(
            executable_steps
        )
    )

    print(
        "JARVIS: Task started."
    )

    print(
        f"JARVIS: {len(executable_steps)} executable step(s)."
    )


    # ========================================================
    # RUN TOOLS
    # ========================================================

    step_counter = 0

    for step in steps:

        # ----------------------------------------------------
        # CHECK FOR CANCELLATION BEFORE EVERY STEP
        # ----------------------------------------------------

        if task_is_cancelled():

            print(
                "JARVIS: Cancellation detected. "
                "Remaining steps abandoned."
            )

            clear_active_context()

            finish_task()

            return "cancelled"


        tool_name = step.get(
            "tool",
            ""
        )

        argument = step.get(
            "argument",
            ""
        )


        if not tool_name:

            continue


        if tool_name == "none":

            continue


        step_counter += 1

        update_task_step(
            step_number=step_counter,
            tool_name=tool_name
        )

        print(
            f"JARVIS: Step "
            f"{step_counter}/{len(executable_steps)}"
        )

        print(
            f"JARVIS: Running {tool_name}"
        )


        try:

            result = tools.run_tool(
                tool_name,
                argument
            )


            # ------------------------------------------------
            # CHECK CANCELLATION AFTER TOOL
            # ------------------------------------------------

            if task_is_cancelled():

                print(
                    "JARVIS: Task cancelled "
                    "after tool execution."
                )

                clear_active_context()

                finish_task()

                return "cancelled"


            # ------------------------------------------------
            # STRUCTURED RESULT
            # ------------------------------------------------

            if isinstance(
                result,
                dict
            ):

                success = result.get(
                    "success",
                    True
                )

                verified = result.get(
                    "verified",
                    True
                )

                message = result.get(
                    "message",
                    "Tool completed."
                )

                message = str(
                    message
                )

            else:

                success = True
                verified = True

                message = str(
                    result
                )


            print(
                "JARVIS:",
                message
            )


            # ------------------------------------------------
            # FAILURE
            # ------------------------------------------------

            if (
                not success
                or not verified
            ):

                task_failed = True

                clear_active_context()

                print(
                    "JARVIS: Task failed."
                )

                conversation.add_message(
                    "assistant",
                    message
                )

                interrupted = speak(
                    message
                )

                if interrupted:

                    pending_input = (
                        listen_after_barge_in()
                    )

                    if pending_input:

                        return "interrupted"

                break


            # ------------------------------------------------
            # SUCCESS
            # ------------------------------------------------

            final_tool_message = (
                message
            )


            update_active_context(
                plan={
                    "steps": [
                        step
                    ]
                },
                result_message=message
            )


            # ------------------------------------------------
            # SINGLE-STEP RESPONSE
            # ------------------------------------------------

            if not multi_step:

                interrupted = speak(
                    message
                )

                if interrupted:

                    pending_input = (
                        listen_after_barge_in()
                    )

                    if pending_input:

                        return "interrupted"

                    return "done"


            task_completed = True


        except Exception as e:

            task_failed = True

            print(
                f"Tool error ({tool_name}):",
                e
            )

            error_message = (
                f"I couldn't complete "
                f"the {tool_name} action."
            )

            clear_active_context()

            conversation.add_message(
                "assistant",
                error_message
            )

            print(
                "JARVIS:",
                error_message
            )

            interrupted = speak(
                error_message
            )

            if interrupted:

                pending_input = (
                    listen_after_barge_in()
                )

                if pending_input:

                    return "interrupted"

            break


    # ========================================================
    # FAILED TASK
    # ========================================================

    if task_failed:

        finish_task()

        return "done"


    # ========================================================
    # MULTI-STEP SUCCESS
    # ========================================================

    if (
        task_completed
        and multi_step
        and final_tool_message
    ):

        update_active_context(
            plan=plan,
            result_message=final_tool_message
        )

        conversation.add_message(
            "assistant",
            final_tool_message
        )

        interrupted = speak(
            final_tool_message
        )

        finish_task()

        if interrupted:

            pending_input = (
                listen_after_barge_in()
            )

            if pending_input:

                return "interrupted"

        return "done"


    # ========================================================
    # SINGLE-STEP SUCCESS
    # ========================================================

    if task_completed:

        conversation.add_message(
            "assistant",
            final_tool_message
        )

        finish_task()

        return "done"


    finish_task()

    return "done"


# ============================================================
# STARTUP
# ============================================================

memory.create_memory()


print(
    f"JARVIS online. Welcome back, {user_name}."
)


speak(
    f"Welcome back, {user_name}. JARVIS is online."
)


# ============================================================
# MAIN STATE MACHINE
# ============================================================

try:

    while True:

        # ====================================================
        # PENDING BARGE-IN COMMAND
        # ====================================================

        if pending_input:

            current_input = (
                pending_input
            )

            pending_input = None


            result = process_command(
                current_input
            )


            if result == "shutdown":

                break


            continue


        # ====================================================
        # CONTINUOUS CONVERSATION
        # ====================================================

        if continuous_mode:

            print(
                "JARVIS: Listening for follow-up..."
            )


            current_input = speech.listen(
                mode="continuous"
            )


            if current_input is None:

                continuous_mode = False

                print(
                    "JARVIS: Conversation timeout."
                )

                continue


            result = process_command(
                current_input
            )


            if result == "shutdown":

                break


            continue


        # ====================================================
        # WAKE-WORD MODE
        # ====================================================

        print(
            "JARVIS: Waiting for wake word..."
        )


        triggered = (
            wakeword.wait_for_wake_word()
        )


        if not triggered:

            continue


        # ====================================================
        # WAKE ACKNOWLEDGEMENT
        # ====================================================

        interrupted = speak(
            f"Yes, {user_name}?"
        )


        if interrupted:

            pending_input = (
                listen_after_barge_in()
            )


            if pending_input:

                continuous_mode = True

                continue


        # ====================================================
        # FIRST COMMAND
        # ====================================================

        current_input = speech.listen(
            mode="wake"
        )


        if current_input is None:

            continue


        # ====================================================
        # ENTER CONTINUOUS MODE
        # ====================================================

        continuous_mode = (
            CONTINUOUS_MODE_DEFAULT
        )


        result = process_command(
            current_input
        )


        if result == "shutdown":

            break


        continue


# ============================================================
# GRACEFUL SHUTDOWN
# ============================================================

except KeyboardInterrupt:

    print(
        "\nJARVIS: Shutdown requested."
    )

    finish_task()

    try:

        voice.clear_interruption()

    except Exception:

        pass

    speak(
        "Goodbye."
    )