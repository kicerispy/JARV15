import os
import subprocess


def create_folder(name):

    path = os.path.join(
        os.getcwd(),
        name
    )

    os.makedirs(path, exist_ok=True)

    return f"Created folder {name}."


def list_files(folder="."):

    try:

        files = os.listdir(folder)

        if not files:
            return "The folder is empty."

        result = "Files found:\n"

        for item in files:
            result += f"- {item}\n"

        return result

    except Exception as e:
        return f"Error: {e}"


def find_file(filename, location="."):

    matches = []

    for root, dirs, files in os.walk(location):

        for file in files:

            if filename.lower() in file.lower():

                matches.append(
                    os.path.join(root, file)
                )


    if matches:

        return "Found:\n" + "\n".join(matches)

    return "No files found."


def open_folder(path="."):

    try:

        subprocess.Popen(
            ["explorer", path]
        )

        return "Opening folder."

    except Exception as e:

        return f"Error: {e}"