import whisper
import sounddevice as sd
from scipy.io.wavfile import write
import torch


# Select GPU if available
device = "cuda" if torch.cuda.is_available() else "cpu"

print("Whisper running on:", device)


# Load Whisper
model = whisper.load_model(
    "base"
)

model = model.to("cuda")

def listen():

    sample_rate = 16000
    recording_time = 5

    print("JARVIS: Listening...")

    audio = sd.rec(
        int(recording_time * sample_rate),
        samplerate=sample_rate,
        channels=1,
        dtype="int16"
    )

    sd.wait()


    write(
        "input.wav",
        sample_rate,
        audio
    )


    result = model.transcribe(
        "input.wav",
        fp16=(device == "cuda")
    )


    text = result["text"].strip()


    if text == "":
        return None


    print(
        "You:",
        text
    )

    return text