import os
import json
import time
import ctypes
import logging

import pyautogui
from ollama import chat


# ==========================================================
# JARVIS VISION ENGINE
# PART 1/4
# ==========================================================


# ==========================================================
# Configuration
# ==========================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)


SCREENSHOT_FILE = os.path.join(
    BASE_DIR,
    "jarvis_screen.png"
)


VISION_MODEL = "gemma4:26b"
VERIFY_MODEL = "gemma4:e2b"


MIN_CONFIDENCE = 0.70


# ==========================================================
# Mouse Calibration
# ==========================================================

MOUSE_OFFSET_X = 300
MOUSE_OFFSET_Y = 0

CLICK_BIAS_X = 25
CLICK_BIAS_Y = 0



# ==========================================================
# Logging
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="[JARVIS] %(message)s"
)



# ==========================================================
# Safe Ollama Vision Call
# ==========================================================

def vision_chat(
    model,
    messages,
    json_mode=False
):

    try:

        options = {
            "model": model,
            "messages": messages
        }


        if json_mode:

            options["format"] = "json"


        return chat(
            **options
        )


    except Exception as e:

        logging.error(
            f"Ollama failure: {e}"
        )

        return None



# ==========================================================
# Capture Screen
# ==========================================================

def capture_screen():

    try:

        screenshot = pyautogui.screenshot()


        screenshot.save(
            SCREENSHOT_FILE
        )


        return {
            "success": True,
            "file": SCREENSHOT_FILE
        }


    except Exception as e:

        return {
            "success": False,
            "error": str(e)
        }



# ==========================================================
# Screen Size
# ==========================================================

def get_screen_size():

    try:

        width, height = pyautogui.size()


        return {
            "width": width,
            "height": height
        }


    except Exception as e:

        return {
            "error": str(e)
        }



# ==========================================================
# Active Window
# ==========================================================

def get_active_window():

    try:

        hwnd = (
            ctypes.windll.user32
            .GetForegroundWindow()
        )


        if not hwnd:

            return "Unknown window"



        length = (
            ctypes.windll.user32
            .GetWindowTextLengthW(hwnd)
        )


        buffer = ctypes.create_unicode_buffer(
            length + 1
        )


        ctypes.windll.user32.GetWindowTextW(
            hwnd,
            buffer,
            length + 1
        )


        title = buffer.value.strip()


        return (
            title
            if title
            else
            "Unknown window"
        )


    except Exception as e:

        return (
            f"Window error: {e}"
        )



# ==========================================================
# Analyze Entire Screen
# ==========================================================

def analyze_screen(
    question="Describe my screen."
):

    result = capture_screen()


    if not result["success"]:

        return result



    response = vision_chat(

        VISION_MODEL,

        [

            {
                "role":"system",

                "content":
"""
You are JARVIS computer vision.

Analyze only visible information.

Identify:

- applications
- browser pages
- windows
- buttons
- text
- menus
- dialogs
- videos
- icons
- clickable elements

Never invent anything.
"""
            },


            {
                "role":"user",

                "content":question,

                "images":[
                    SCREENSHOT_FILE
                ]
            }

        ]

    )


    if not response:

        return (
            "Vision failed."
        )


    return (
        response["message"]["content"]
        .strip()
    )



# ==========================================================
# Extract JSON From AI Response
# ==========================================================

def extract_json(text):

    try:

        return json.loads(
            text
        )


    except:


        start = text.find("{")

        end = text.rfind("}")


        if (
            start != -1
            and
            end != -1
        ):

            try:

                return json.loads(
                    text[start:end+1]
                )


            except:

                pass


    return None

# ==========================================================
# YouTube Target Detection
# ==========================================================

def is_youtube_target(target):

    target = str(target).lower()


    keywords = [

        "youtube",
        "first video",
        "first result",
        "video result",
        "first youtube"

    ]


    return any(
        word in target
        for word in keywords
    )



# ==========================================================
# Build Vision Localization Prompt
# ==========================================================

def build_locator_prompt(
    target,
    width,
    height
):


    if is_youtube_target(target):

        return f"""

You are JARVIS precision screen locator.

Find the FIRST NORMAL YOUTUBE VIDEO RESULT.

Screenshot resolution:

width={width}
height={height}


Ignore:

- YouTube logo
- browser tabs
- address bar
- search box
- menus
- Shorts
- advertisements
- sponsored results
- sidebars


The target should be a normal video result.

A normal video result contains:

- thumbnail
- title
- channel name
- metadata


Return ONLY JSON:

{{
"found": true,
"confidence": 0.95,
"left": 100,
"top": 300,
"right": 900,
"bottom": 500,
"description": "first YouTube video result"
}}


If you cannot confidently locate it:

{{
"found": false,
"confidence": 0.0,
"left":0,
"top":0,
"right":0,
"bottom":0,
"description":"not found"
}}


Do not guess.

"""


    return f"""

You are JARVIS UI localization AI.

Locate this visible target:

{target}


Screenshot:

width={width}
height={height}


Return ONLY JSON:

{{
"found":true,
"confidence":0.95,
"left":100,
"top":100,
"right":300,
"bottom":150,
"description":"target"
}}


Rules:

- Coordinates are screenshot pixels.
- Bounding box must surround the real object.
- Do not guess.
- Prefer clickable elements.
- Stay inside screen boundaries.

"""



# ==========================================================
# Clean And Validate Coordinates
# ==========================================================

def clean_location(
    data,
    width,
    height
):

    try:

        data["left"] = int(
            data.get(
                "left",
                0
            )
        )

        data["top"] = int(
            data.get(
                "top",
                0
            )
        )

        data["right"] = int(
            data.get(
                "right",
                0
            )
        )

        data["bottom"] = int(
            data.get(
                "bottom",
                0
            )
        )


    except:


        return {

            "found":False,
            "confidence":0

        }



    data["left"] = max(
        0,
        min(
            data["left"],
            width-1
        )
    )


    data["top"] = max(
        0,
        min(
            data["top"],
            height-1
        )
    )


    data["right"] = max(
        0,
        min(
            data["right"],
            width-1
        )
    )


    data["bottom"] = max(
        0,
        min(
            data["bottom"],
            height-1
        )
    )



    if (

        data["right"] <= data["left"]

        or

        data["bottom"] <= data["top"]

    ):


        data["found"] = False



    confidence = float(
        data.get(
            "confidence",
            0
        )
    )


    data["confidence"] = confidence



    if confidence < MIN_CONFIDENCE:

        data["found"] = False



    return data



# ==========================================================
# Locate Target On Screen
# ==========================================================

def find_screen_target(target):


    screenshot = capture_screen()


    if not screenshot["success"]:


        return {

            "found":False,
            "confidence":0

        }



    image = pyautogui.screenshot()


    width,height = image.size



    prompt = build_locator_prompt(

        target,
        width,
        height

    )



    response = vision_chat(

        VISION_MODEL,

        [

            {
                "role":"system",
                "content":prompt
            },


            {
                "role":"user",

                "content":
                    f"Locate: {target}",

                "images":[
                    SCREENSHOT_FILE
                ]
            }

        ],

        json_mode=True

    )



    if not response:


        return {

            "found":False,
            "confidence":0

        }



    result = extract_json(

        response["message"]["content"]

    )



    if not result:


        return {

            "found":False,
            "confidence":0

        }



    result = clean_location(

        result,
        width,
        height

    )



    logging.info(
        f"Located: {result.get('description')}"
    )


    logging.info(
        f"Confidence: {result.get('confidence')}"
    )


    return result
# ==========================================================
# Coordinate Conversion
# ==========================================================

def convert_coordinates(
    x,
    y,
    clicking=False
):

    x = x + MOUSE_OFFSET_X
    y = y + MOUSE_OFFSET_Y


    if clicking:

        x += CLICK_BIAS_X
        y += CLICK_BIAS_Y



    screen_width, screen_height = pyautogui.size()


    x = max(
        0,
        min(
            x,
            screen_width - 1
        )
    )


    y = max(
        0,
        min(
            y,
            screen_height - 1
        )
    )


    return x, y



# ==========================================================
# Bounding Box Center
# ==========================================================

def get_center(
    result
):

    x = (

        result["left"]

        +

        result["right"]

    ) // 2



    y = (

        result["top"]

        +

        result["bottom"]

    ) // 2



    return x, y



# ==========================================================
# Move Mouse To Target
# ==========================================================

def move_mouse_to_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            f"Could not find {target}"

        }



    vision_x, vision_y = get_center(
        result
    )



    mouse_x, mouse_y = convert_coordinates(

        vision_x,

        vision_y

    )



    logging.info(

        f"Moving mouse: {mouse_x},{mouse_y}"

    )



    pyautogui.moveTo(

        mouse_x,

        mouse_y,

        duration=0.3

    )



    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        ),

        "message":
        f"Moved mouse to {result.get('description')}"

    }



# ==========================================================
# Click Target
# ==========================================================

def click_screen_target(
    target
):

    result = find_screen_target(
        target
    )



    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            f"Could not locate {target}"

        }



    vision_x, vision_y = get_center(
        result
    )



    mouse_x, mouse_y = convert_coordinates(

        vision_x,

        vision_y,

        clicking=True

    )



    logging.info(

        f"Clicking: {mouse_x},{mouse_y}"

    )



    pyautogui.moveTo(

        mouse_x,

        mouse_y,

        duration=0.2

    )


    pyautogui.click()



    time.sleep(
        0.5
    )



    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        ),

        "message":
        f"Clicked {result.get('description')}"

    }



# ==========================================================
# Double Click Target
# ==========================================================

def double_click_screen_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            "Target not found."

        }



    vision_x, vision_y = get_center(
        result
    )



    mouse_x, mouse_y = convert_coordinates(

        vision_x,

        vision_y,

        clicking=True

    )



    logging.info(

        f"Double clicking {mouse_x},{mouse_y}"

    )



    pyautogui.moveTo(

        mouse_x,

        mouse_y,

        duration=0.2

    )



    pyautogui.doubleClick(

        interval=0.15

    )



    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        ),

        "message":
        f"Double clicked {result.get('description')}"

    }



# ==========================================================
# Scroll
# ==========================================================

def scroll_screen(
    direction="down"
):

    direction = str(
        direction
    ).lower()



    amount = -5


    if "up" in direction:

        amount = 5


    elif "bottom" in direction:

        amount = -15


    elif "top" in direction:

        amount = 15



    pyautogui.scroll(
        amount
    )


    return {

        "success":True,

        "message":
        f"Scrolled {direction}"

    }



# ==========================================================
# Type Text
# ==========================================================

def type_text(
    text
):

    if not text:

        return {

            "success":False,

            "message":
            "No text supplied."

        }



    pyautogui.write(

        text,

        interval=0.02

    )



    return {

        "success":True,

        "message":
        "Text entered."

    }



# ==========================================================
# Keyboard Input
# ==========================================================

def press_key(
    key
):

    allowed = [

        "enter",
        "escape",
        "esc",
        "tab",
        "space",
        "backspace",
        "delete",
        "up",
        "down",
        "left",
        "right",
        "home",
        "end"

    ]



    key = str(
        key
    ).lower()



    if key == "esc":

        key = "escape"



    if key not in allowed:

        return {

            "success":False,

            "message":
            "Key not allowed."

        }



    pyautogui.press(
        key
    )



    return {

        "success":True,

        "message":
        f"Pressed {key}"

    }
# ==========================================================
# Verify Action Result
# ==========================================================

def verify_screen(
    instruction
):

    capture = capture_screen()


    if not capture["success"]:

        return False



    response = vision_chat(

        VERIFY_MODEL,

        [

            {
                "role":"system",

                "content":
"""
You are JARVIS verification system.

Check whether an action succeeded.

Only answer JSON.

Format:

{
"success":true,
"confidence":0.95,
"reason":"what changed"
}

Do not guess.
"""
            },


            {
                "role":"user",

                "content":
                instruction,

                "images":[
                    SCREENSHOT_FILE
                ]
            }

        ],

        json_mode=True

    )



    if not response:

        return False



    data = extract_json(

        response["message"]["content"]

    )



    if not data:

        return False



    return (

        data.get(
            "success",
            False
        )

    )



# ==========================================================
# Wait For Screen Change
# ==========================================================

def wait_for_change(
    timeout=5
):

    start = time.time()


    old = pyautogui.screenshot()



    while time.time() - start < timeout:


        time.sleep(
            0.5
        )


        new = pyautogui.screenshot()



        if old.tobytes() != new.tobytes():

            return True



    return False



# ==========================================================
# Safe Click
# ==========================================================

def safe_click(
    target
):

    result = click_screen_target(
        target
    )


    if not result["success"]:

        return result



    changed = wait_for_change()



    return {

        "success":
            changed,

        "message":
        (
            "Click completed."
            if changed
            else
            "Clicked but screen did not change."
        )

    }



# ==========================================================
# Open Application
# ==========================================================

def open_application(
    name
):

    pyautogui.press(
        "win"
    )


    time.sleep(
        0.5
    )


    type_text(
        name
    )


    time.sleep(
        0.5
    )


    press_key(
        "enter"
    )


    return {

        "success":True,

        "message":
        f"Opening {name}"

    }



# ==========================================================
# JARVIS Command Router
# ==========================================================

def execute_command(
    command
):

    command = str(
        command
    ).lower()



    if "click" in command:


        target = (

            command

            .replace(
                "click",
                ""
            )

            .strip()

        )


        return click_screen_target(
            target
        )



    if "double click" in command:


        target = (

            command

            .replace(
                "double click",
                ""
            )

            .strip()

        )


        return double_click_screen_target(
            target
        )



    if "move" in command:


        target = (

            command

            .replace(
                "move",
                ""
            )

            .strip()

        )


        return move_mouse_to_target(
            target
        )



    if "scroll" in command:


        return scroll_screen(
            command
        )



    if "type" in command:


        text = (

            command

            .replace(
                "type",
                ""
            )

            .strip()

        )


        return type_text(
            text
        )



    if "open" in command:


        app = (

            command

            .replace(
                "open",
                ""
            )

            .strip()

        )


        return open_application(
            app
        )



    return {

        "success":False,

        "message":
        "Unknown command."

    }



# ==========================================================
# Debug Information
# ==========================================================

def jarvis_status():

    return {

        "active_window":
            get_active_window(),

        "screen":
            get_screen_size(),

        "vision_model":
            VISION_MODEL,

        "verify_model":
            VERIFY_MODEL

    }



# ==========================================================
# TEST MODE
# ==========================================================

if __name__ == "__main__":


    print(
        "JARVIS Vision Engine Online"
    )


    print(
        jarvis_status()
    )


    while True:


        command = input(
            "\nJARVIS> "
        )


        if command.lower() in [
            "exit",
            "quit"
        ]:

            break



        result = execute_command(
            command
        )


        print(
            json.dumps(
                result,
                indent=2
            )
        )
# ==========================================================
# JARVIS VISION ENGINE
# PART 2/4
# ==========================================================


# ==========================================================
# Coordinate Conversion
# ==========================================================

def convert_coordinates(
    x,
    y,
    clicking=False
):

    x += MOUSE_OFFSET_X
    y += MOUSE_OFFSET_Y


    if clicking:

        x += CLICK_BIAS_X
        y += CLICK_BIAS_Y



    screen_width, screen_height = pyautogui.size()


    x = max(
        0,
        min(
            x,
            screen_width - 1
        )
    )


    y = max(
        0,
        min(
            y,
            screen_height - 1
        )
    )


    return x, y



# ==========================================================
# Get Bounding Box Center
# ==========================================================

def get_center(
    result
):

    center_x = (

        result["left"]

        +

        result["right"]

    ) // 2


    center_y = (

        result["top"]

        +

        result["bottom"]

    ) // 2


    return center_x, center_y



# ==========================================================
# Move Mouse
# ==========================================================

def move_mouse_to_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            f"Could not find {target}"

        }



    vision_x, vision_y = get_center(
        result
    )


    mouse_x, mouse_y = convert_coordinates(
        vision_x,
        vision_y
    )



    logging.info(
        f"Moving mouse to {mouse_x},{mouse_y}"
    )



    pyautogui.moveTo(
        mouse_x,
        mouse_y,
        duration=0.3
    )


    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        ),

        "target":
        result.get(
            "description",
            target
        )

    }



# ==========================================================
# Click Target
# ==========================================================

def click_screen_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            f"Target not found: {target}"

        }



    x, y = get_center(
        result
    )


    x, y = convert_coordinates(
        x,
        y,
        clicking=True
    )


    logging.info(
        f"Clicking {x},{y}"
    )



    pyautogui.moveTo(
        x,
        y,
        duration=0.2
    )


    pyautogui.click()



    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        ),

        "message":
        f"Clicked {result.get('description')}"

    }



# ==========================================================
# Double Click Target
# ==========================================================

def double_click_screen_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            "Target not found"

        }



    x, y = get_center(
        result
    )


    x, y = convert_coordinates(
        x,
        y,
        clicking=True
    )



    logging.info(
        f"Double clicking {x},{y}"
    )



    pyautogui.moveTo(
        x,
        y,
        duration=0.2
    )


    pyautogui.doubleClick(
        interval=0.15
    )



    return {

        "success":True,

        "confidence":
        result.get(
            "confidence",
            0
        )

    }



# ==========================================================
# Right Click
# ==========================================================

def right_click_screen_target(
    target
):

    result = find_screen_target(
        target
    )


    if not result.get(
        "found",
        False
    ):

        return {

            "success":False,

            "message":
            "Target not found"

        }



    x,y = get_center(
        result
    )


    x,y = convert_coordinates(
        x,
        y,
        clicking=True
    )


    pyautogui.moveTo(
        x,
        y,
        duration=0.2
    )


    pyautogui.rightClick()



    return {

        "success":True,

        "message":
        f"Right clicked {target}"

    }



# ==========================================================
# Scroll Control
# ==========================================================

def scroll_screen(
    direction="down",
    amount=None
):

    direction = str(
        direction
    ).lower()



    if amount is None:

        amount = 5



    if "up" in direction:

        amount = abs(amount)


    else:

        amount = -abs(amount)



    pyautogui.scroll(
        amount
    )



    return {

        "success":True,

        "message":
        f"Scrolled {direction}"

    }



# ==========================================================
# Move Mouse Absolute
# ==========================================================

def move_absolute(
    x,
    y
):

    try:

        pyautogui.moveTo(
            int(x),
            int(y),
            duration=0.2
        )


        return {

            "success":True,

            "message":
            f"Moved to {x},{y}"

        }


    except Exception as e:

        return {

            "success":False,

            "error":str(e)

        }



# ==========================================================
# Type Text Safely
# ==========================================================

def type_text(
    text
):

    if not text:

        return {

            "success":False,

            "message":
            "Empty text"

        }



    pyautogui.write(
        str(text),
        interval=0.02
    )



    return {

        "success":True,

        "message":
        "Text typed"

    }



# ==========================================================
# Keyboard Keys
# ==========================================================

def press_key(
    key
):

    allowed = {

        "enter",
        "escape",
        "esc",
        "tab",
        "space",
        "backspace",
        "delete",
        "up",
        "down",
        "left",
        "right",
        "home",
        "end"

    }



    key = str(
        key
    ).lower()



    if key == "esc":

        key = "escape"



    if key not in allowed:

        return {

            "success":False,

            "message":
            "Key blocked"

        }



    pyautogui.press(
        key
    )


    return {

        "success":True,

        "message":
        f"Pressed {key}"

    }
# ==========================================================
# Advanced Mouse Actions
# ==========================================================


def drag_screen_target(
    source,
    destination
):

    start = find_screen_target(
        source
    )


    end = find_screen_target(
        destination
    )


    if not start.get("found"):

        return {
            "success":False,
            "message":f"Could not find {source}"
        }


    if not end.get("found"):

        return {
            "success":False,
            "message":f"Could not find {destination}"
        }



    sx, sy = get_center(
        start
    )


    ex, ey = get_center(
        end
    )



    sx, sy = convert_coordinates(
        sx,
        sy,
        True
    )


    ex, ey = convert_coordinates(
        ex,
        ey,
        True
    )



    logging.info(
        f"Dragging {sx},{sy} -> {ex},{ey}"
    )



    pyautogui.moveTo(
        sx,
        sy,
        duration=0.2
    )


    pyautogui.dragTo(
        ex,
        ey,
        duration=0.8,
        button="left"
    )



    return {

        "success":True,

        "message":
        f"Dragged {source} to {destination}"

    }





# ==========================================================
# Hotkey Support
# ==========================================================


def press_hotkey(
    keys
):

    if not keys:

        return {
            "success":False,
            "message":"No keys supplied."
        }



    if isinstance(keys,str):

        keys = keys.split("+")



    keys = [
        str(k).lower().strip()
        for k in keys
    ]



    allowed = [

        "ctrl",
        "alt",
        "shift",
        "win",
        "enter",
        "tab",
        "esc",
        "space",
        "a",
        "c",
        "v",
        "x",
        "z",
        "f",
        "s"

    ]



    for key in keys:

        if key not in allowed:

            return {

                "success":False,

                "message":
                f"Blocked key: {key}"

            }



    pyautogui.hotkey(
        *keys
    )



    return {

        "success":True,

        "message":
        f"Pressed {'+'.join(keys)}"

    }





# ==========================================================
# Screenshot Memory
# ==========================================================


last_screen_hash = None



def screen_changed():

    global last_screen_hash


    screenshot = pyautogui.screenshot()


    current = hash(
        screenshot.tobytes()
    )



    if last_screen_hash is None:

        last_screen_hash = current

        return False



    changed = (
        current != last_screen_hash
    )


    last_screen_hash = current


    return changed





# ==========================================================
# Wait Until Element Appears
# ==========================================================


def wait_for_element(
    target,
    timeout=10
):

    start = time.time()



    while (
        time.time() - start
        <
        timeout
    ):


        result = find_screen_target(
            target
        )



        if result.get(
            "found",
            False
        ):

            return {

                "success":True,

                "confidence":
                result.get(
                    "confidence",
                    0
                )

            }



        time.sleep(
            0.5
        )



    return {

        "success":False,

        "message":
        f"{target} did not appear"

    }





# ==========================================================
# Click With Retry
# ==========================================================


def retry_click(
    target,
    attempts=3
):


    for i in range(
        attempts
    ):


        result = click_screen_target(
            target
        )


        if result.get(
            "success"
        ):

            return result



        logging.warning(
            f"Click attempt {i+1} failed"
        )


        time.sleep(
            1
        )



    return {

        "success":False,

        "message":
        "All click attempts failed."

    }
# ==========================================================
# JARVIS MEMORY STATE
# ==========================================================

class JarvisState:

    def __init__(self):

        self.last_command = None
        self.last_target = None
        self.last_result = None
        self.history = []


    def remember(
        self,
        command,
        result
    ):

        self.last_command = command
        self.last_result = result

        self.history.append(
            {
                "command": command,
                "result": result
            }
        )


        if len(self.history) > 50:

            self.history.pop(0)



STATE = JarvisState()



# ==========================================================
# Command Cleanup
# ==========================================================

def clean_command(
    command
):

    command = str(
        command
    ).lower().strip()


    replacements = {

        "please ": "",
        "jarvis ": "",
        "can you ": "",
        "could you ": ""

    }


    for old,new in replacements.items():

        command = command.replace(
            old,
            new
        )


    return command




# ==========================================================
# Better Target Extraction
# ==========================================================

def extract_target(
    command,
    words
):

    target = command


    for word in words:

        target = target.replace(
            word,
            ""
        )


    return target.strip()




# ==========================================================
# Improved Command Router
# ==========================================================

def jarvis_execute(
    command
):

    original = command


    command = clean_command(
        command
    )


    result = None



    # --------------------------
    # Screenshot analysis
    # --------------------------

    if (
        "analyze screen"
        in command
        or
        "describe screen"
        in command
    ):

        result = {

            "success":True,

            "screen":
            analyze_screen()

        }




    # --------------------------
    # Status
    # --------------------------

    elif "status" in command:


        result = {

            "success":True,

            "status":
            jarvis_status()

        }




    # --------------------------
    # Click
    # --------------------------

    elif command.startswith(
        "click"
    ):


        target = extract_target(

            command,

            [
                "click"
            ]

        )


        result = click_screen_target(
            target
        )





    # --------------------------
    # Double click
    # --------------------------

    elif command.startswith(
        "double click"
    ):


        target = extract_target(

            command,

            [
                "double click"
            ]

        )


        result = double_click_screen_target(
            target
        )





    # --------------------------
    # Move
    # --------------------------

    elif command.startswith(
        "move"
    ):


        target = extract_target(

            command,

            [
                "move"
            ]

        )


        result = move_mouse_to_target(
            target
        )





    # --------------------------
    # Type
    # --------------------------

    elif command.startswith(
        "type"
    ):


        text = extract_target(

            command,

            [
                "type"
            ]

        )


        result = type_text(
            text
        )





    # --------------------------
    # Press
    # --------------------------

    elif command.startswith(
        "press"
    ):


        key = extract_target(

            command,

            [
                "press"
            ]

        )


        result = press_key(
            key
        )





    # --------------------------
    # Scroll
    # --------------------------

    elif command.startswith(
        "scroll"
    ):


        result = scroll_screen(
            command
        )





    # --------------------------
    # Open app
    # --------------------------

    elif command.startswith(
        "open"
    ):


        app = extract_target(

            command,

            [
                "open"
            ]

        )


        result = open_application(
            app
        )





    else:


        result = {

            "success":False,

            "message":
            "Command not understood."

        }




    STATE.remember(
        original,
        result
    )


    return result




# ==========================================================
# Emergency Stop
# ==========================================================

def emergency_stop():

    pyautogui.keyDown(
        "esc"
    )

    time.sleep(
        0.1
    )

    pyautogui.keyUp(
        "esc"
    )


    return {

        "success":True,

        "message":
        "Emergency stop executed."

    }





# ==========================================================
# Save Logs
# ==========================================================

def save_history():

    file = os.path.join(
        BASE_DIR,
        "jarvis_history.json"
    )


    try:

        with open(
            file,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(

                STATE.history,

                f,

                indent=2

            )


        return True


    except:

        return False




# ==========================================================
# Final Launcher
# ==========================================================

def start_jarvis():

    print(
        """
================================

        JARVIS ONLINE

 Vision Engine Loaded
 Ollama Connected
 Mouse Control Ready

 Type commands.
 Type EXIT to close.

================================
"""
    )


    while True:


        try:


            command = input(
                "\nJARVIS >>> "
            )



            if command.lower() in [
                "exit",
                "quit",
                "shutdown"
            ]:


                save_history()


                print(
                    "JARVIS shutting down."
                )


                break




            if command.lower() == "stop":

                print(
                    emergency_stop()
                )

                continue





            result = jarvis_execute(
                command
            )


            print(

                json.dumps(

                    result,

                    indent=2

                )

            )



        except KeyboardInterrupt:


            save_history()


            print(
                "\nJARVIS interrupted."
            )


            break



        except Exception as e:


            print(

                {
                    "error":str(e)
                }

            )





# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    start_jarvis()