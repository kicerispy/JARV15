import json
from ollama import chat


MODEL = "gemma4:26b"


def classify_intent(command):

    prompt = f"""
Classify this user request.

User:
{command}


Return ONLY JSON.

Possible types:

computer_action
information_request
conversation


Rules:

computer_action:
- open apps
- click things
- browse websites
- type searches
- control mouse
- interact with UI


information_request:
- explain
- summarize
- facts
- questions


conversation:
- greetings
- emotions
- casual speech


Example:

{{
"type":"computer_action",
"confidence":0.95
}}

"""


    response = chat(
        model=MODEL,
        messages=[
            {
                "role":"user",
                "content":prompt
            }
        ],
        format="json"
    )


    return json.loads(
        response["message"]["content"]
    )