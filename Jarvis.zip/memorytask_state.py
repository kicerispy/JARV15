# ==========================================================
# JARVIS MEMORY TASK STATE
# ==========================================================

import json
import time
import os
import logging


# ==========================================================
# Configuration
# ==========================================================

STATE_FILE = "jarvis_task_state.json"


logging.basicConfig(
    level=logging.INFO,
    format="[MEMORY] %(message)s"
)



# ==========================================================
# Task State Object
# ==========================================================

class TaskState:


    def __init__(self):

        self.task_id = None

        self.user_command = ""

        self.status = "idle"

        self.current_step = 0

        self.total_steps = 0

        self.steps = []

        self.completed_steps = []

        self.failed_steps = []

        self.created = time.time()

        self.updated = time.time()



    # ------------------------------------------------------

    def create_task(
        self,
        command,
        steps
    ):

        self.task_id = int(
            time.time()
        )


        self.user_command = command


        self.steps = steps


        self.total_steps = len(
            steps
        )


        self.current_step = 0


        self.status = "running"


        self.save()



        logging.info(
            "Task created"
        )



    # ------------------------------------------------------

    def get_current_step(self):

        if self.current_step >= self.total_steps:

            return None


        return self.steps[
            self.current_step
        ]



    # ------------------------------------------------------

    def complete_current_step(self):

        step = self.get_current_step()


        if step:


            self.completed_steps.append(
                step
            )


            self.current_step += 1



        if self.current_step >= self.total_steps:

            self.status = "completed"



        self.updated = time.time()


        self.save()



    # ------------------------------------------------------

    def fail_current_step(
        self,
        reason
    ):

        step = self.get_current_step()


        self.failed_steps.append(

            {
                "step":step,
                "reason":reason
            }

        )


        self.status = "error"


        self.updated=time.time()


        self.save()



    # ------------------------------------------------------

    def pause(self):

        self.status="paused"

        self.save()



    # ------------------------------------------------------

    def resume(self):

        self.status="running"

        self.save()



    # ------------------------------------------------------

    def cancel(self):

        self.status="cancelled"

        self.save()



    # ------------------------------------------------------

    def save(self):

        data = {

            "task_id":
                self.task_id,

            "user_command":
                self.user_command,

            "status":
                self.status,

            "current_step":
                self.current_step,

            "total_steps":
                self.total_steps,

            "steps":
                self.steps,

            "completed_steps":
                self.completed_steps,

            "failed_steps":
                self.failed_steps,

            "created":
                self.created,

            "updated":
                self.updated
        }


        with open(
            STATE_FILE,
            "w"
        ) as f:


            json.dump(
                data,
                f,
                indent=4
            )



    # ------------------------------------------------------

    def load(self):

        if not os.path.exists(
            STATE_FILE
        ):

            return False



        with open(
            STATE_FILE,
            "r"
        ) as f:

            data=json.load(f)



        self.__dict__.update(
            data
        )


        return True



# ==========================================================
# Global Memory Instance
# ==========================================================


task_memory = TaskState()



# ==========================================================
# Helper Functions
# ==========================================================


def remember_task(
    command,
    steps
):

    task_memory.create_task(
        command,
        steps
    )



def next_task_step():

    return (
        task_memory
        .get_current_step()
    )



def task_complete():

    task_memory.complete_current_step()



def task_failed(
    reason
):

    task_memory.fail_current_step(
        reason
    )



def current_state():

    return {

        "status":
            task_memory.status,

        "step":
            task_memory.current_step,

        "total":
            task_memory.total_steps,

        "next":
            task_memory.get_current_step()

    }