from ollama import chat
import json


model = "gemma4:e2b"


def decide_tool(user_input):

    response = chat(
        model=model,
        format="json",
        messages=[
            {
                "role": "system",
                "content": """
You are a tool decision system for JARVIS.

Your job is to decide if a user request needs a tool.

Available tools:

open_program:
- Opens Windows applications.
- Available apps:
  notepad
  calculator
  paint

system_status:
- Reports CPU and RAM usage.

create_folder:
- Creates a new folder.

list_files:
- Lists files in a folder.

find_file:
- Finds a file by name.

open_folder:
- Opens a Windows folder.

web_search:
- Searches the internet for information.
- Use this for current information, news, websites, latest versions, prices, updates, or anything requiring live information.


Return ONLY valid JSON.

Format:

{
 "tool": "tool_name",
 "argument": "argument"
}


Examples:

User:
Open Notepad

Response:
{
 "tool": "open_program",
 "argument": "notepad"
}


User:
What is my computer status?

Response:
{
 "tool": "system_status",
 "argument": ""
}


User:
Create a folder called AI Projects

Response:
{
 "tool": "create_folder",
 "argument": "AI Projects"
}


User:
Find main.py

Response:
{
 "tool": "find_file",
 "argument": "main.py"
}


User:
Search the web for the latest Python version

Response:
{
 "tool": "web_search",
 "argument": "latest Python version"
}


User:
What is a Python function?

Response:
{
 "tool": "none",
 "argument": ""
}
"""
            },
            {
                "role": "user",
                "content": user_input
            }
        ]
    )


    try:
        result = json.loads(
            response["message"]["content"]
        )

        return result


    except Exception:

        print("Tool router failed.")
        print(
            response["message"]["content"]
        )

        return {
            "tool": "none",
            "argument": ""
        }