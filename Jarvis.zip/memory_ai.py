from ollama import chat
import memory


model = "gemma4:e2b"


def analyze_memory(text):

    response = chat(
        model=model,
        messages=[
            {
                "role": "system",
                "content": """
You decide if a user message contains information worth remembering.

Remember:
- preferences
- hobbies
- important facts
- personal settings

Do NOT remember:
- temporary questions
- random conversation

If it is worth remembering, reply with:
SAVE: information

If not, reply:
NO
"""
            },
            {
                "role": "user",
                "content": text
            }
        ]
    )

    result = response["message"]["content"]

    if result.startswith("SAVE:"):

        fact = result.replace("SAVE:", "").strip()

        memory.save_memory(fact)

        return True

    return False