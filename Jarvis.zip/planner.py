import json
import logging

from ollama import chat


# ==========================================================
# JARVIS TASK PLANNER
# ==========================================================


PLANNER_MODEL = "gemma4:26b"



logging.basicConfig(
    level=logging.INFO,
    format="[PLANNER] %(message)s"
)



# ==========================================================
# Available Actions
# ==========================================================


AVAILABLE_ACTIONS = [

    "open_application",

    "open_url",

    "click",

    "double_click",

    "move",

    "type",

    "press",

    "scroll",

    "wait",

    "verify"

]



# ==========================================================
# Safe LLM Call
# ==========================================================


def planner_chat(messages):

    try:

        response = chat(

            model=PLANNER_MODEL,

            messages=messages,

            format="json"

        )

        return response


    except Exception as e:

        logging.error(
            f"Planner error: {e}"
        )

        return None



# ==========================================================
# JSON Extraction
# ==========================================================


def extract_json(text):

    try:

        return json.loads(text)


    except:


        start=text.find("{")

        end=text.rfind("}")


        if start!=-1 and end!=-1:

            try:

                return json.loads(
                    text[start:end+1]
                )

            except:

                pass


    return None



# ==========================================================
# Build Planner Prompt
# ==========================================================


def planner_prompt():

    return """

You are JARVIS task planner.

Your job:

Convert a user request into executable computer actions.


You do NOT:

- answer questions
- research information
- explain
- browse
- summarize


You ONLY create steps.


Available actions:

open_application
open_url
click
double_click
move
type
press
scroll
wait
verify


Rules:

1. Return ONLY JSON.

2. Every step must use one available action.

3. Use vision targets when clicking unknown UI.

4. Never guess coordinates.

5. Never interpret search terms.

6. Browser searches are:

open_url
type
press enter
click result


Format:

{
"goal":"short description",

"steps":[

{
"action":"action_name",
"target":"value"
}

]

}


Example:

User:
Open YouTube and search cats


Output:

{
"goal":"search YouTube",

"steps":[

{
"action":"open_url",
"target":"https://youtube.com"
},

{
"action":"type",
"target":"cats"
},

{
"action":"press",
"target":"enter"
}

]

}

"""



# ==========================================================
# Create Plan
# ==========================================================


def create_plan(user_command):


    response = planner_chat(

        [

        {
        "role":"system",
        "content":
        planner_prompt()
        },


        {
        "role":"user",
        "content":
        user_command
        }

        ]

    )



    if not response:

        return None



    data = extract_json(

        response["message"]["content"]

    )



    if not data:

        return None



    return validate_plan(
        data
    )



# ==========================================================
# Validate Plan
# ==========================================================


def validate_plan(plan):


    if "steps" not in plan:

        return None



    clean=[]


    for step in plan["steps"]:


        action = step.get(
            "action"
        )


        target = step.get(
            "target",
            ""
        )


        if action not in AVAILABLE_ACTIONS:

            logging.warning(
                f"Rejected action {action}"
            )

            continue



        clean.append({

            "action":action,

            "target":target

        })



    plan["steps"]=clean


    return plan



# ==========================================================
# Debug
# ==========================================================


if __name__=="__main__":


    while True:


        command=input(
            "USER> "
        )


        if command=="exit":

            break



        plan=create_plan(
            command
        )


        print(
            json.dumps(
                plan,
                indent=2
            )
        )