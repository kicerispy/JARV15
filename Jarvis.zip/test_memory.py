import memory

memory.create_memory()

memory.save_memory(
    "My name is Jordan"
)

print(memory.get_memories())