import json

FILE = "conversation_history.json"


def load_history():
    try:
        with open(FILE, "r") as file:
            return json.load(file)
    except:
        return []


def save_history(history):
    with open(FILE, "w") as file:
        json.dump(history, file, indent=4)


def add_message(role, content):
    history = load_history()

    history.append({
        "role": role,
        "content": content
    })

    save_history(history)


def get_history():
    return load_history()