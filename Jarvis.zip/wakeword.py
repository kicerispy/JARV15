import json
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import onnxruntime as ort
import torch

from heed.audio import StreamingHighpass, log_mel


# ==================================================
# Paths
# ==================================================

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "Jarvis" / "export" / "wake.onnx"
METADATA_PATH = BASE_DIR / "Jarvis" / "export" / "wake.json"


# ==================================================
# Microphone
# ==================================================

MIC_DEVICE = 1

SAMPLE_RATE = 16000

# Process audio every 100 ms.
CHUNK_SIZE = 1600


# ==================================================
# Load Heed metadata
# ==================================================

if not MODEL_PATH.exists():
    raise FileNotFoundError(
        f"Heed model not found:\n{MODEL_PATH}"
    )

if not METADATA_PATH.exists():
    raise FileNotFoundError(
        f"Heed metadata not found:\n{METADATA_PATH}"
    )


with open(METADATA_PATH, "r", encoding="utf-8") as f:
    META = json.load(f)


WAKE_THRESHOLD = float(
    META["threshold"]
)

CONSECUTIVE_FRAMES = int(
    META["trigger"]["consecutive_frames"]
)

REFRACTORY_SECONDS = float(
    META["trigger"]["refractory_seconds"]
)

ENERGY_GATE_DBFS = float(
    META["energy_gate"]["rms_threshold_dbfs"]
)

VOICE_BAND_LO = float(
    META["energy_gate"]["voice_band_lo_hz"]
)

VOICE_BAND_HI = float(
    META["energy_gate"]["voice_band_hi_hz"]
)

VOICE_BAND_MIN_FRACTION = float(
    META["energy_gate"]["voice_band_min_fraction"]
)


# ==================================================
# Heed ONNX Runtime
# ==================================================

session = ort.InferenceSession(
    str(MODEL_PATH),
    providers=["CPUExecutionProvider"],
)

INPUT_NAME = session.get_inputs()[0].name
OUTPUT_NAME = session.get_outputs()[0].name


# ==================================================
# Streaming audio preprocessing
# ==================================================

preprocessor = StreamingHighpass(
    cutoff_hz=100.0,
    sample_rate=SAMPLE_RATE,
    order=8,
    apply_mains_notch=True,
)


# ==================================================
# Rolling audio buffer
# ==================================================

AUDIO_WINDOW_SAMPLES = 16000

audio_buffer = np.zeros(
    AUDIO_WINDOW_SAMPLES,
    dtype=np.float32,
)

samples_seen = 0


# ==================================================
# Wake state
# ==================================================

_last_wake_time = 0.0
_consecutive_hits = 0


# ==================================================
# Helpers
# ==================================================

def reset_detector():
    global audio_buffer
    global samples_seen
    global _consecutive_hits

    preprocessor.reset()

    audio_buffer.fill(0)

    samples_seen = 0

    _consecutive_hits = 0


def get_rms_dbfs(audio):
    """
    Return RMS level in dBFS.
    """

    audio = np.asarray(
        audio,
        dtype=np.float32,
    )

    if audio.size == 0:
        return -120.0

    rms = float(
        np.sqrt(
            np.mean(
                np.square(audio)
            )
        )
    )

    if rms <= 1e-12:
        return -120.0

    return 20.0 * np.log10(rms)


def voice_band_fraction(audio):
    """
    Estimate how much spectral energy is present
    in the configured voice-frequency band.
    """

    audio = np.asarray(
        audio,
        dtype=np.float32,
    )

    if audio.size < 32:
        return 0.0

    window = np.hanning(
        len(audio)
    )

    spectrum = np.fft.rfft(
        audio * window
    )

    power = np.abs(spectrum) ** 2

    freqs = np.fft.rfftfreq(
        len(audio),
        d=1.0 / SAMPLE_RATE,
    )

    total_power = float(
        np.sum(power)
    )

    if total_power <= 1e-12:
        return 0.0

    mask = (
        (freqs >= VOICE_BAND_LO)
        &
        (freqs <= VOICE_BAND_HI)
    )

    voice_power = float(
        np.sum(power[mask])
    )

    return voice_power / total_power


def energy_gate_passes(audio):
    """
    Heed's silence/noise gate.

    This keeps us from running the model
    when essentially nothing useful is present.
    """

    rms_dbfs = get_rms_dbfs(audio)

    if rms_dbfs < ENERGY_GATE_DBFS:
        return False

    fraction = voice_band_fraction(
        audio
    )

    if fraction < VOICE_BAND_MIN_FRACTION:
        return False

    return True


def append_audio(audio):
    """
    Append filtered audio to the rolling
    one-second buffer.
    """

    global audio_buffer
    global samples_seen

    audio = np.asarray(
        audio,
        dtype=np.float32,
    )

    if audio.size == 0:
        return

    # --------------------------------------------------
    # Stateful Heed filtering
    # --------------------------------------------------

    filtered = preprocessor(
        audio
    )

    filtered = np.asarray(
        filtered,
        dtype=np.float32,
    )

    n = len(filtered)

    # --------------------------------------------------
    # Rolling one-second buffer
    # --------------------------------------------------

    if n >= AUDIO_WINDOW_SAMPLES:

        audio_buffer[:] = filtered[
            -AUDIO_WINDOW_SAMPLES:
        ]

        samples_seen = AUDIO_WINDOW_SAMPLES

    else:

        audio_buffer[:-n] = (
            audio_buffer[n:]
        )

        audio_buffer[-n:] = filtered

        samples_seen = min(
            AUDIO_WINDOW_SAMPLES,
            samples_seen + n,
        )


def get_wake_probability():
    """
    Convert the current 1-second audio
    buffer into Heed's required 40x101
    log-mel representation and run ONNX.
    """

    # Do not run until one full second exists.
    if samples_seen < AUDIO_WINDOW_SAMPLES:
        return 0.0

    waveform = torch.from_numpy(
        audio_buffer.copy()
    )

    # --------------------------------------------------
    # Heed log-mel + CMN
    # --------------------------------------------------

    mel = log_mel(
        waveform,
        apply_cmn=True,
    )

    # Expected shape:
    # (1, 40, 101)

    mel_np = (
        mel
        .detach()
        .cpu()
        .numpy()
        .astype(np.float32)
    )

    # --------------------------------------------------
    # ONNX
    # --------------------------------------------------

    outputs = session.run(
        [OUTPUT_NAME],
        {
            INPUT_NAME: mel_np
        },
    )

    logit = float(
        np.asarray(
            outputs[0]
        ).reshape(-1)[0]
    )

    # --------------------------------------------------
    # Sigmoid
    # --------------------------------------------------

    probability = 1.0 / (
        1.0 + np.exp(-logit)
    )

    return float(
        probability
    )


# ==================================================
# Main wake listener
# ==================================================

def wait_for_wake_word():

    global _last_wake_time
    global _consecutive_hits

    print(
        "JARVIS: Waiting for wake word..."
    )

    print(
        f"JARVIS: Custom Heed model loaded "
        f"(threshold={WAKE_THRESHOLD:.3f})"
    )

    print(
        f"JARVIS: Listening on microphone "
        f"device {MIC_DEVICE}"
    )

    # --------------------------------------------------
    # Persistent post-wake cooldown
    # --------------------------------------------------

    elapsed = (
        time.time()
        - _last_wake_time
    )

    if elapsed < REFRACTORY_SECONDS:

        time.sleep(
            REFRACTORY_SECONDS
            - elapsed
        )

    # --------------------------------------------------
    # Reset streaming detector
    # --------------------------------------------------

    reset_detector()

    # --------------------------------------------------
    # Open microphone
    # --------------------------------------------------

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        blocksize=CHUNK_SIZE,
        channels=1,
        dtype="float32",
        device=MIC_DEVICE,
    ) as stream:

        while True:

            audio, overflowed = (
                stream.read(CHUNK_SIZE)
            )

            if overflowed:
                continue

            audio = np.asarray(
                audio[:, 0],
                dtype=np.float32,
            )

            # --------------------------------------------------
            # Always ingest audio
            #
            # The filter and rolling buffer must remain
            # continuous even while the energy gate fails.
            # --------------------------------------------------

            append_audio(
                audio
            )

            # --------------------------------------------------
            # Energy gate
            # --------------------------------------------------

            if not energy_gate_passes(
                audio
            ):

                _consecutive_hits = 0

                continue

            # --------------------------------------------------
            # Wake prediction
            # --------------------------------------------------

            probability = (
                get_wake_probability()
            )

            # --------------------------------------------------
            # Debug output
            # --------------------------------------------------

            if probability > 0.20:

                print(
                    f"JARVIS score: "
                    f"{probability:.3f}"
                )

            # --------------------------------------------------
            # Consecutive-frame trigger
            # --------------------------------------------------

            if probability >= WAKE_THRESHOLD:

                _consecutive_hits += 1

            else:

                _consecutive_hits = 0

            # --------------------------------------------------
            # Trigger
            # --------------------------------------------------

            if (
                _consecutive_hits
                >= CONSECUTIVE_FRAMES
            ):

                print(
                    "================================"
                )

                print(
                    "JARVIS: WAKE WORD DETECTED"
                )

                print(
                    f"JARVIS: score={probability:.3f}"
                )

                print(
                    "================================"
                )

                _last_wake_time = (
                    time.time()
                )

                _consecutive_hits = 0

                return True