import json
import logging
import time

from ollama import chat


MODEL = "gemma4:26b"


logging.basicConfig(
    level=logging.INFO,
    format="[TASK] %(message)s"
)



# ==========================================================
# Intent Detection
# ==========================================================

def classify_intent(command):

    prompt = f"""
You are JARVIS intent classifier.

Classify the user command.

Possible intents:

COMPUTER_ACTION
- opening apps
- clicking buttons
- typing
- browsing websites
- interacting with UI


WEB_SEARCH
- user wants information
- user wants facts


QUESTION
- normal conversation


Return ONLY JSON:

{{
"intent":"",
"reason":""
}}


User:

{command}

"""


    response = chat(
        model=MODEL,
        messages=[
            {
                "role":"user",
                "content":prompt
            }
        ],
        format="json"
    )


    try:

        return json.loads(
            response["message"]["content"]
        )

    except:

        return {
            "intent":"QUESTION"
        }



# ==========================================================
# Browser Task Planner
# ==========================================================


def create_browser_plan(command):


    prompt=f"""

You are JARVIS browser automation planner.


Convert the task into UI actions.


Available actions:


OPEN_APP
OPEN_URL
TYPE
CLICK
WAIT
VERIFY



Rules:

NEVER use web search.

The browser is controlled visually.

Return JSON array only.


Example:

[
{{
"action":"OPEN_APP",
"target":"Chrome"
}},

{{
"action":"OPEN_URL",
"target":"https://youtube.com"
}},

{{
"action":"TYPE",
"target":"Wi-Fi skeleton"
}},

{{
"action":"PRESS",
"target":"enter"
}},

{{
"action":"CLICK",
"target":"first YouTube video result"
}}
]



Task:

{command}


"""


    response = chat(
        model=MODEL,
        messages=[
            {
                "role":"user",
                "content":prompt
            }
        ],
        format="json"
    )


    return json.loads(
        response["message"]["content"]
    )



# ==========================================================
# Execute Plan
# ==========================================================


def execute_browser_plan(
        plan,
        vision_engine
):


    for index,step in enumerate(plan):


        logging.info(
            f"Step {index+1}/{len(plan)}"
        )


        action = step["action"]

        target = step.get(
            "target",
            ""
        )



        if action=="OPEN_APP":

            vision_engine.open_application(
                target
            )


        elif action=="OPEN_URL":

            vision_engine.open_website(
                target
            )


        elif action=="TYPE":

            vision_engine.type_text(
                target
            )


        elif action=="PRESS":

            vision_engine.press_key(
                target
            )


        elif action=="CLICK":

            result = (
                vision_engine
                .safe_click(
                    target
                )
            )


            if not result["success"]:

                logging.error(
                    "Click failed"
                )

                return False



        elif action=="WAIT":

            time.sleep(2)



    return True



# ==========================================================
# Main JARVIS Brain
# ==========================================================


def handle_command(
    command,
    vision_engine
):


    intent = classify_intent(
        command
    )


    logging.info(
        intent
    )



    if intent["intent"]=="COMPUTER_ACTION":


        plan=create_browser_plan(
            command
        )


        logging.info(
            f"Plan: {plan}"
        )


        return execute_browser_plan(
            plan,
            vision_engine
        )



    elif intent["intent"]=="WEB_SEARCH":

        return {
            "type":"SEARCH",
            "query":command
        }



    else:

        return {
            "type":"CHAT",
            "text":
            "Normal conversation handler."
        }