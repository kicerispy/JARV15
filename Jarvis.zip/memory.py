import sqlite3

DATABASE = "jarvis_memory.db"


def create_memory():
    conn = sqlite3.connect(DATABASE)

    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY,
        memory TEXT
    )
    """)

    conn.commit()
    conn.close()


def save_memory(text):
    conn = sqlite3.connect(DATABASE)

    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO memories (memory) VALUES (?)",
        (text,)
    )

    conn.commit()
    conn.close()


def get_memories():

    conn = sqlite3.connect(DATABASE)

    cursor = conn.cursor()

    cursor.execute(
        "SELECT memory FROM memories"
    )

    memories = cursor.fetchall()

    conn.close()

    return memories