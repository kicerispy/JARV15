from ddgs import DDGS


def web_search(query):

    results = []

    try:

        with DDGS() as ddgs:

            search_results = ddgs.text(
                query,
                max_results=5
            )

            for result in search_results:

                results.append(
                    result["title"]
                    + "\n"
                    + result["body"]
                )


        if results:

            return "\n\n".join(results)


        return "No results found."


    except Exception as e:

        return f"Web search error: {e}"