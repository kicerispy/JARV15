import psutil
import time


start_time = time.time()


def get_status(model):

    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()

    uptime = int(
        time.time() - start_time
    )

    return f"""
JARVIS Status:

Model:
{model}

CPU:
{cpu}%

RAM:
{ram.percent}%

Uptime:
{uptime} seconds
"""