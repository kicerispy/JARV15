import whisper
import sounddevice as sd
from scipy.io.wavfile import write
import torch
import numpy as np
import time


# ============================================================
# WHISPER SETUP
# ============================================================

device = (
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)

print(
    "Whisper running on:",
    device
)

model = whisper.load_model(
    "base",
    device=device
)


# ============================================================
# MICROPHONE SETTINGS
# ============================================================

MIC_DEVICE = 1

SAMPLE_RATE = 16000

CHUNK_SIZE = 1024


# ============================================================
# SPEECH DETECTION
# ============================================================

# Normal speech start threshold.
SILENCE_THRESHOLD = 500

# How long silence must continue before recording ends.
SILENCE_DURATION = 0.8

# Maximum recording length for normal commands.
MAX_RECORDING_SECONDS = 10


# ============================================================
# BARGE-IN SETTINGS
# ============================================================

# When speech comes from the TTS barge-in monitor, we already
# know the user has started speaking.
#
# We therefore give Whisper extra time to capture the complete
# interruption rather than ending immediately after the first
# quiet chunk.
BARGE_IN_MINIMUM_CAPTURE = 1.25

# Additional silence tolerance for a barge-in command.
BARGE_IN_SILENCE_DURATION = 1.0


# ============================================================
# LISTENING TIMEOUTS
# ============================================================

# Normal wake-word mode:
# how long JARVIS waits for you to begin speaking.
START_TIMEOUT = 5.0


# Continuous conversation mode:
# shorter timeout so JARVIS does not sit silently
# for five seconds after every response.
CONTINUOUS_START_TIMEOUT = 2.5


# ============================================================
# PREBUFFER
# ============================================================

# Small amount of audio captured before speech
# crosses the threshold.
PREBUFFER_SECONDS = 0.35

PREBUFFER_CHUNKS = max(
    1,
    int(
        PREBUFFER_SECONDS
        * SAMPLE_RATE
        / CHUNK_SIZE
    )
)


# ============================================================
# GET MICROPHONE VOLUME
# ============================================================

def get_volume(audio):

    audio = np.asarray(
        audio,
        dtype=np.int16
    )

    if len(audio) == 0:
        return 0.0

    return float(
        np.sqrt(
            np.mean(
                audio.astype(
                    np.float32
                ) ** 2
            )
        )
    )


# ============================================================
# LISTEN
#
# mode:
#   "wake"       = normal wake-word interaction
#   "continuous" = follow-up conversation
#
# initial_audio:
#   Optional audio captured by the TTS barge-in monitor.
# ============================================================

def listen(
    initial_audio=None,
    mode="wake"
):

    print(
        "JARVIS: Listening..."
    )


    # --------------------------------------------------------
    # Determine whether this is a barge-in capture
    # --------------------------------------------------------

    is_barge_in = (
        initial_audio is not None
    )


    # --------------------------------------------------------
    # Select appropriate startup timeout
    # --------------------------------------------------------

    if mode == "continuous":

        start_timeout = (
            CONTINUOUS_START_TIMEOUT
        )

    else:

        start_timeout = (
            START_TIMEOUT
        )


    # --------------------------------------------------------
    # State
    # --------------------------------------------------------

    recorded_chunks = []

    speech_started = False

    silence_start = None

    start_time = time.time()

    recording_start_time = None


    # --------------------------------------------------------
    # Initial audio supplied by the barge-in monitor
    # --------------------------------------------------------

    if initial_audio is not None:

        initial_audio = np.asarray(
            initial_audio,
            dtype=np.int16
        )

        if len(initial_audio) > 0:

            recorded_chunks.append(
                initial_audio
            )

            speech_started = True

            recording_start_time = (
                time.time()
            )

            silence_start = None


    # ========================================================
    # OPEN MICROPHONE
    # ========================================================

    try:

        with sd.InputStream(
            samplerate=SAMPLE_RATE,
            blocksize=CHUNK_SIZE,
            channels=1,
            dtype="int16",
            device=MIC_DEVICE
        ) as stream:


            while True:

                audio, overflowed = (
                    stream.read(
                        CHUNK_SIZE
                    )
                )


                if overflowed:
                    continue


                audio = np.asarray(
                    audio[:, 0],
                    dtype=np.int16
                )


                volume = get_volume(
                    audio
                )


                current_time = time.time()


                # ==================================================
                # WAITING FOR USER TO BEGIN SPEAKING
                # ==================================================

                if not speech_started:

                    if (
                        volume
                        > SILENCE_THRESHOLD
                    ):

                        speech_started = True

                        recording_start_time = (
                            current_time
                        )

                        recorded_chunks.append(
                            audio
                        )

                        silence_start = None

                    elif (
                        current_time
                        - start_time
                        >= start_timeout
                    ):

                        print(
                            "JARVIS: "
                            "I didn't hear anything."
                        )

                        return None

                    continue


                # ==================================================
                # USER IS SPEAKING
                # ==================================================

                recorded_chunks.append(
                    audio
                )


                # ==================================================
                # BARGE-IN CAPTURE PROTECTION
                # ==================================================

                if is_barge_in:

                    elapsed_capture = (
                        current_time
                        - recording_start_time
                    )

                    # Do not allow a barge-in recording to end
                    # during the first part of the capture.
                    #
                    # This is important for short words such as:
                    # "Stop"
                    # "Cancel"
                    # "Wait"
                    #
                    # The monitor may have triggered before the
                    # entire word reached the speech recorder.
                    if (
                        elapsed_capture
                        < BARGE_IN_MINIMUM_CAPTURE
                    ):

                        silence_start = None

                        continue


                # ==================================================
                # DETECT END OF SPEECH
                # ==================================================

                silence_limit = (
                    BARGE_IN_SILENCE_DURATION
                    if is_barge_in
                    else SILENCE_DURATION
                )


                if (
                    volume
                    < SILENCE_THRESHOLD
                ):

                    if silence_start is None:

                        silence_start = (
                            current_time
                        )

                    elif (
                        current_time
                        - silence_start
                        >= silence_limit
                    ):

                        break

                else:

                    silence_start = None


                # ==================================================
                # MAXIMUM RECORDING TIME
                # ==================================================

                if (
                    current_time
                    - start_time
                    >= MAX_RECORDING_SECONDS
                ):

                    break


    except Exception as e:

        print(
            "JARVIS microphone error:",
            e
        )

        return None


    # ========================================================
    # MAKE SURE WE HAVE AUDIO
    # ========================================================

    if not recorded_chunks:

        return None


    audio_data = np.concatenate(
        recorded_chunks
    )


    # ========================================================
    # REMOVE VERY SHORT / EMPTY CAPTURES
    # ========================================================

    if len(audio_data) < (
        int(
            0.20
            * SAMPLE_RATE
        )
    ):

        print(
            "JARVIS: Audio capture too short."
        )

        return None


    # ========================================================
    # SAVE RECORDING
    # ========================================================

    filename = "input.wav"


    try:

        write(
            filename,
            SAMPLE_RATE,
            audio_data
        )

    except Exception as e:

        print(
            "JARVIS audio save error:",
            e
        )

        return None


    # ========================================================
    # WHISPER TRANSCRIPTION
    # ========================================================

    try:

        result = model.transcribe(
            filename,
            fp16=(
                device == "cuda"
            ),
            language="en",
            temperature=0
        )

    except Exception as e:

        print(
            "Whisper error:",
            e
        )

        return None


    # ========================================================
    # CLEAN TRANSCRIPTION
    # ========================================================

    text = (
        result["text"]
        .strip()
    )


    if not text:

        return None


    # Collapse repeated whitespace.
    text = " ".join(
        text.split()
    )


    print(
        "You:",
        text
    )


    return text