TOOLS = {}


def register_tool(
    name,
    description,
    function
):

    TOOLS[name] = {

        "description": description,

        "function": function

    }



def get_tools():

    return {

        name:data["description"]

        for name,data in TOOLS.items()

    }



def run_tool(
    name,
    args
):

    if name not in TOOLS:

        return {
            "success":False,
            "error":"Unknown tool"
        }


    return TOOLS[name]["function"](
        **args
    )