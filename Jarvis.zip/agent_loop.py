class JarvisAgent:


    def __init__(
        self,
        planner,
        controller,
        vision
    ):

        self.planner = planner
        self.controller = controller
        self.vision = vision



    def run(self, command):


        plan = self.planner.create_plan(
            command
        )


        state = {

            "goal":command,

            "steps":plan["steps"],

            "current":0,

            "history":[]

        }


        while state["current"] < len(state["steps"]):


            step = state["steps"][
                state["current"]
            ]


            print(
                f"Executing {step}"
            )


            result = self.controller.execute(
                step
            )


            state["history"].append(
                result
            )


            if not result["success"]:


                recovery = self.recover(
                    state,
                    result
                )


                if recovery:

                    state["steps"].extend(
                        recovery
                    )

                else:

                    break



            else:

                state["current"] += 1



        return state