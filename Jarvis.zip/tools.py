import subprocess
import psutil
import json
import re
import os
import time
import webbrowser

from datetime import datetime
from urllib.parse import urlencode, quote_plus
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from zoneinfo import ZoneInfo

import file_tools
import web_tools
import web_summary
import jarvis_status
import screen_vision


# ==================================================
# Weather
# ==================================================

DEFAULT_WEATHER_LOCATION = "Chicago"

GEOCODING_URL = (
    "https://geocoding-api.open-meteo.com/v1/search"
)

WEATHER_URL = (
    "https://api.open-meteo.com/v1/forecast"
)

WEATHER_CODES = {
    0: "clear sky",
    1: "mainly clear",
    2: "partly cloudy",
    3: "overcast",
    45: "fog",
    48: "depositing rime fog",
    51: "light drizzle",
    53: "moderate drizzle",
    55: "dense drizzle",
    56: "light freezing drizzle",
    57: "dense freezing drizzle",
    61: "slight rain",
    63: "moderate rain",
    65: "heavy rain",
    66: "light freezing rain",
    67: "heavy freezing rain",
    71: "slight snow fall",
    73: "moderate snow fall",
    75: "heavy snow fall",
    77: "snow grains",
    80: "slight rain showers",
    81: "moderate rain showers",
    82: "violent rain showers",
    85: "slight snow showers",
    86: "heavy snow showers",
    95: "thunderstorm",
    96: "thunderstorm with slight hail",
    99: "thunderstorm with heavy hail",
}


def _http_get_json(url, params):

    query = urlencode(params)
    full_url = f"{url}?{query}"

    request = Request(
        full_url,
        headers={
            "User-Agent": "JARVIS/1.0"
        }
    )

    with urlopen(
        request,
        timeout=10
    ) as response:

        return json.loads(
            response.read().decode("utf-8")
        )


def _extract_weather_location(request):

    request = request.strip()

    if not request:
        return DEFAULT_WEATHER_LOCATION

    match = re.search(
        r"\bin\s+(.+?)(?:\s+tomorrow|\s+today|\s+right now|\s+now)?$",
        request,
        re.IGNORECASE,
    )

    if match:

        location = match.group(1).strip()

        location = re.sub(
            r"\b(today|tomorrow|right now|now)$",
            "",
            location,
            flags=re.IGNORECASE,
        ).strip()

        if location:
            return location

    match = re.search(
        r"\bfor\s+(.+?)(?:\s+tomorrow|\s+today|\s+right now|\s+now)?$",
        request,
        re.IGNORECASE,
    )

    if match:

        location = match.group(1).strip()

        location = re.sub(
            r"\b(today|tomorrow|right now|now)$",
            "",
            location,
            flags=re.IGNORECASE,
        ).strip()

        if location:
            return location

    return DEFAULT_WEATHER_LOCATION


def _is_tomorrow_request(request):

    return "tomorrow" in request.lower()


def _geocode_location(location):

    data = _http_get_json(
        GEOCODING_URL,
        {
            "name": location,
            "count": 1,
            "language": "en",
            "format": "json",
        }
    )

    results = data.get(
        "results",
        []
    )

    if not results:
        return None

    result = results[0]

    return {
        "name": result.get(
            "name",
            location
        ),
        "admin1": result.get(
            "admin1",
            ""
        ),
        "country": result.get(
            "country",
            ""
        ),
        "latitude": result["latitude"],
        "longitude": result["longitude"],
        "timezone": result.get(
            "timezone",
            "auto"
        ),
    }


def weather(request=""):

    try:

        location_query = (
            _extract_weather_location(
                request
            )
        )

        location = _geocode_location(
            location_query
        )

        if location is None:

            return (
                f"I couldn't find weather data for "
                f"{location_query}."
            )

        data = _http_get_json(
            WEATHER_URL,
            {
                "latitude": location["latitude"],
                "longitude": location["longitude"],
                "current": (
                    "temperature_2m,"
                    "apparent_temperature,"
                    "relative_humidity_2m,"
                    "precipitation,"
                    "rain,"
                    "showers,"
                    "snowfall,"
                    "weather_code,"
                    "wind_speed_10m"
                ),
                "daily": (
                    "weather_code,"
                    "temperature_2m_max,"
                    "temperature_2m_min,"
                    "precipitation_probability_max"
                ),
                "temperature_unit": "fahrenheit",
                "wind_speed_unit": "mph",
                "timezone": location["timezone"],
                "forecast_days": 2,
            }
        )

        current = data.get(
            "current",
            {}
        )

        daily = data.get(
            "daily",
            {}
        )

        if not current:

            return (
                "I couldn't retrieve current "
                "weather conditions."
            )

        temperature = current.get(
            "temperature_2m"
        )

        apparent = current.get(
            "apparent_temperature"
        )

        humidity = current.get(
            "relative_humidity_2m"
        )

        wind = current.get(
            "wind_speed_10m"
        )

        weather_code = current.get(
            "weather_code"
        )

        description = WEATHER_CODES.get(
            weather_code,
            "unknown conditions"
        )

        location_name = location["name"]

        if location.get("admin1"):

            location_name += (
                f", {location['admin1']}"
            )

        if _is_tomorrow_request(request):

            dates = daily.get(
                "time",
                []
            )

            if len(dates) >= 2:

                tomorrow_max = daily[
                    "temperature_2m_max"
                ][1]

                tomorrow_min = daily[
                    "temperature_2m_min"
                ][1]

                tomorrow_code = daily[
                    "weather_code"
                ][1]

                tomorrow_precip = daily[
                    "precipitation_probability_max"
                ][1]

                tomorrow_description = (
                    WEATHER_CODES.get(
                        tomorrow_code,
                        "unknown conditions"
                    )
                )

                return (
                    f"Tomorrow in {location_name}, "
                    f"expect {tomorrow_description}, "
                    f"with a high of "
                    f"{tomorrow_max:.0f} degrees "
                    f"and a low of "
                    f"{tomorrow_min:.0f}. "
                    f"The maximum precipitation "
                    f"probability is "
                    f"{tomorrow_precip:.0f} percent."
                )

        today_high = None
        today_low = None
        today_precip = None

        if daily.get("time"):

            today_high = daily[
                "temperature_2m_max"
            ][0]

            today_low = daily[
                "temperature_2m_min"
            ][0]

            today_precip = daily[
                "precipitation_probability_max"
            ][0]

        response = (
            f"In {location_name}, it's currently "
            f"{temperature:.0f} degrees and "
            f"{description}. "
        )

        if apparent is not None:

            response += (
                f"It feels like "
                f"{apparent:.0f}. "
            )

        if humidity is not None:

            response += (
                f"Humidity is "
                f"{humidity:.0f} percent. "
            )

        if wind is not None:

            response += (
                f"Wind is "
                f"{wind:.0f} miles per hour. "
            )

        if today_high is not None:

            response += (
                f"Today's high is "
                f"{today_high:.0f}, "
                f"with a low of "
                f"{today_low:.0f}. "
            )

        if today_precip is not None:

            response += (
                f"The precipitation probability "
                f"reaches {today_precip:.0f} percent."
            )

        return response

    except HTTPError as e:

        return (
            "The weather service returned "
            f"HTTP error {e.code}."
        )

    except URLError:

        return (
            "I couldn't reach the weather service. "
            "Please check the internet connection."
        )

    except Exception as e:

        print(
            "Weather error:",
            e
        )

        return (
            "I encountered an error while "
            "retrieving the weather."
        )


# ==================================================
# Time
# ==================================================

TIMEZONE_ALIASES = {

    "chicago": "America/Chicago",
    "illinois": "America/Chicago",

    "new york": "America/New_York",
    "new york city": "America/New_York",

    "los angeles": "America/Los_Angeles",
    "san francisco": "America/Los_Angeles",
    "seattle": "America/Los_Angeles",

    "denver": "America/Denver",
    "phoenix": "America/Phoenix",

    "london": "Europe/London",

    "paris": "Europe/Paris",
    "berlin": "Europe/Berlin",

    "tokyo": "Asia/Tokyo",
    "seoul": "Asia/Seoul",

    "beijing": "Asia/Shanghai",
    "shanghai": "Asia/Shanghai",

    "singapore": "Asia/Singapore",
    "sydney": "Australia/Sydney",

    "dubai": "Asia/Dubai",

    "mumbai": "Asia/Kolkata",
    "delhi": "Asia/Kolkata",

    "toronto": "America/Toronto",
    "vancouver": "America/Vancouver",

    "mexico city": "America/Mexico_City",
}


def _resolve_timezone(argument):

    name = argument.strip()

    if not name:
        return None

    lowered = name.lower()

    if lowered in TIMEZONE_ALIASES:

        return TIMEZONE_ALIASES[
            lowered
        ]

    return name


def current_time(argument=""):

    timezone_name = _resolve_timezone(
        argument
    )

    if timezone_name:

        try:

            now = datetime.now(
                ZoneInfo(timezone_name)
            )

            display_name = argument.strip()

            return (
                f"The time in {display_name} is "
                f"{now.strftime('%I:%M %p').lstrip('0')}."
            )

        except Exception:

            return (
                f"I don't recognize the timezone "
                f"{argument.strip()}."
            )

    now = datetime.now()

    return (
        f"It's {now.strftime('%I:%M %p').lstrip('0')}."
    )


# ==================================================
# Date
# ==================================================

def current_date():

    now = datetime.now()

    return (
        f"Today is "
        f"{now.strftime('%A, %B %d, %Y')}."
    )


# ==================================================
# Wait
# ==================================================

def wait_seconds(argument=""):

    try:

        seconds = float(
            argument
        )

        seconds = max(
            0.0,
            min(
                seconds,
                30.0
            )
        )

        time.sleep(
            seconds
        )

        return (
            f"Waited {seconds:.1f} seconds."
        )

    except Exception:

        return "Invalid wait duration."


# ==================================================
# Open Website
# ==================================================

WEBSITE_URLS = {

    "youtube":
        "https://www.youtube.com/",

    "google":
        "https://www.google.com/",

    "amazon":
        "https://www.amazon.com/",

    "reddit":
        "https://www.reddit.com/",
}


def open_website(argument=""):

    argument = argument.strip()

    if (
        argument.startswith("http://")
        or argument.startswith("https://")
    ):

        url = argument

    else:

        site = argument.lower()

        url = WEBSITE_URLS.get(
            site
        )

        if url is None:

            return (
                f"I don't have {argument} "
                f"configured as a website."
            )

    try:

        webbrowser.open(
            url
        )

        return (
            f"Opening {argument}."
        )

    except Exception as e:

        print(
            "Website launch error:",
            e
        )

        return (
            f"I couldn't open {argument}."
        )


# ==================================================
# Search Website Directly
# ==================================================

def search_website(
    site,
    query=""
):

    site = site.lower().strip()
    query = query.strip()

    if not query:

        return (
            "No search query was provided."
        )

    # --------------------------------------------------
    # Build direct search URL
    # --------------------------------------------------

    if site == "youtube":

        url = (
            "https://www.youtube.com/results"
            "?search_query="
            + quote_plus(query)
        )

        display_name = "YouTube"

    elif site == "google":

        url = (
            "https://www.google.com/search?q="
            + quote_plus(query)
        )

        display_name = "Google"

    elif site == "amazon":

        url = (
            "https://www.amazon.com/s?k="
            + quote_plus(query)
        )

        display_name = "Amazon"

    elif site == "reddit":

        url = (
            "https://www.reddit.com/search/"
            "?q="
            + quote_plus(query)
        )

        display_name = "Reddit"

    else:

        return (
            f"I don't know how to search {site}."
        )

    # --------------------------------------------------
    # Open search results
    # --------------------------------------------------

    try:

        webbrowser.open(
            url
        )

        return (
            f"Searching {display_name} for {query}."
        )

    except Exception as e:

        print(
            "Website search error:",
            e
        )

        return (
            f"I couldn't search {display_name}."
        )


# ==================================================
# Program Launching
# ==================================================

PROGRAM_ALIASES = {

    "notepad":
        "notepad.exe",

    "calculator":
        "calc.exe",

    "calc":
        "calc.exe",

    "paint":
        "mspaint.exe",

    "microsoft paint":
        "mspaint.exe",

    "file explorer":
        "explorer.exe",

    "explorer":
        "explorer.exe",

    "command prompt":
        "cmd.exe",

    "cmd":
        "cmd.exe",

    "powershell":
        "powershell.exe",

    "terminal":
        "wt.exe",

    "windows terminal":
        "wt.exe",

    "edge":
        "msedge.exe",

    "microsoft edge":
        "msedge.exe",

    "firefox":
        "firefox.exe",

    "discord":
        "Discord.exe",

    "spotify":
        "Spotify.exe",

    "steam":
        "steam.exe",

    "word":
        "winword.exe",

    "microsoft word":
        "winword.exe",

    "excel":
        "excel.exe",

    "microsoft excel":
        "excel.exe",

    "powerpoint":
        "powerpnt.exe",

    "microsoft powerpoint":
        "powerpnt.exe",
}


def find_chrome():

    possible_paths = [

        os.path.expandvars(
            r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"
        ),

        os.path.expandvars(
            r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
        ),

        os.path.expandvars(
            r"%LocalAppData%\Google\Chrome\Application\chrome.exe"
        ),
    ]

    for path in possible_paths:

        if os.path.exists(path):

            return path

    return None


def open_program(program):

    program = program.lower().strip()

    # ----------------------------------------------
    # Chrome
    # ----------------------------------------------

    if program in {
        "chrome",
        "google chrome",
    }:

        chrome_path = find_chrome()

        if chrome_path:

            try:

                subprocess.Popen(
                    [chrome_path]
                )

                return "Opening Chrome."

            except Exception as e:

                print(
                    "Chrome launch error:",
                    e
                )

                return (
                    "I found Chrome, but I couldn't "
                    "launch it."
                )

        return (
            "I couldn't find Google Chrome "
            "on this computer."
        )

    # ----------------------------------------------
    # Other applications
    # ----------------------------------------------

    executable = PROGRAM_ALIASES.get(
        program
    )

    if executable is None:

        return (
            f"I don't have {program} configured "
            f"as an application I can open."
        )

    try:

        subprocess.Popen(
            executable
        )

        return (
            f"Opening {program}."
        )

    except FileNotFoundError:

        return (
            f"I couldn't find {program} "
            f"on this computer."
        )

    except Exception as e:

        print(
            "Open program error:",
            e
        )

        return (
            f"I couldn't open {program}."
        )


# ==================================================
# System Status
# ==================================================

def system_status():

    cpu = psutil.cpu_percent(
        interval=1
    )

    ram = psutil.virtual_memory()

    return (
        f"CPU usage is {cpu}%.\n"
        f"RAM usage is {ram.percent}%."
    )


# ==================================================
# Main Tool Dispatcher
# ==================================================

def run_tool(
    tool_name,
    argument=""
):

    if tool_name == "weather":

        return weather(
            argument
        )

    elif tool_name == "current_time":

        return current_time(
            argument
        )

    elif tool_name == "current_date":

        return current_date()

    elif tool_name == "wait":

        return wait_seconds(
            argument
        )

    elif tool_name == "open_website":

        return open_website(
            argument
        )

    elif tool_name == "search_website":

        # Expected format:
        # site|query

        if "|" not in argument:

            return (
                "Invalid website search format."
            )

        site, query = (
            argument.split(
                "|",
                1
            )
        )

        return search_website(
            site,
            query
        )

    elif tool_name == "open_program":

        return open_program(
            argument
        )

    elif tool_name == "system_status":

        return system_status()

    elif tool_name == "create_folder":

        return file_tools.create_folder(
            argument
        )

    elif tool_name == "list_files":

        return file_tools.list_files(
            argument
        )

    elif tool_name == "find_file":

        return file_tools.find_file(
            argument
        )

    elif tool_name == "open_folder":

        return file_tools.open_folder(
            argument
        )

    elif tool_name == "web_search":

        results = web_tools.web_search(
            argument
        )

        return web_summary.summarize_web_results(
            results
        )

    elif tool_name == "jarvis_status":

        return jarvis_status.get_status(
            "gemma4:e2b"
        )

    elif tool_name == "capture_screen":

        return screen_vision.capture_screen()

    elif tool_name == "screen_size":

        return screen_vision.get_screen_size()

    elif tool_name == "get_active_window":

        return screen_vision.get_active_window()

    elif tool_name == "analyze_screen":

        return screen_vision.analyze_screen(
            argument
        )

    elif tool_name == "move_mouse":

        return screen_vision.move_mouse_to_target(
            argument
        )

    elif tool_name == "click_screen":

        return screen_vision.click_screen_target(
            argument
        )

    elif tool_name == "double_click_screen":

        return (
            screen_vision.double_click_screen_target(
                argument
            )
        )

    elif tool_name == "scroll_screen":

        return screen_vision.scroll_screen(
            argument
        )

    elif tool_name == "verify_screen":

        return screen_vision.verify_screen_state(
            argument
        )

    elif tool_name == "type_text":

        return screen_vision.type_text(
            argument
        )

    elif tool_name == "press_key":

        return screen_vision.press_key(
            argument
        )

    else:

        return "Unknown tool requested."